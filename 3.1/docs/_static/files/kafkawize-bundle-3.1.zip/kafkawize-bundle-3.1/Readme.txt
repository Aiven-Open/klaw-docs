Installation :

How to Run the application

Steps to run with Cassandra as Metastore:

Install Apache Cassandra
Setup project KafkawizeClusterApi and update server.port if necessary in application properties
Start KafkaClusterApi
Setup project KafkaWize, and configure Cassandra running host, Cluster api host, in application properties
Set db.storetype=cassandra in application.properties
Start KafkaWize (from local profile for example) From directory kafkawize-web
mvn spring-boot:run -Plocal application.properties are configured in kafkawize-conf\environments\local OR run the generated jar with application properties in spring class path
Cassandra db setup will be done on the startup of the application. It is not required to run the scripts manually.
Steps to run with Rdbms as Metastore:

Install an Rdbms database (Mysql or Oracle or ..)
Setup project KafkawizeClusterApi and update server.port if necessary in application properties
Start KafkaClusterApi
Setup project KafkaWize, and configure Cassandra running host, Cluster api host, in application properties
Set db.storetype=rdbms and few other datasource properties in application.properties
Start KafkaWize (from local profile for example) From directory kafkawize-web
mvn spring-boot:run -Plocal application.properties are configured in kafkawize-conf\environments\local OR run the generated jar with application properties in spring class path
Run the ddl and insert scripts available in kafkawize-web/src/main/resources/scripts/base/rdbms.
By default KafkaWize runs on port 9097. Access it by http://localhost:9097/kafkawize

Default Teams Team1 Team2 Team3

Default Users(with pwds)

uiuser1/user    from Team1
uiuser2/user    from Team2
uiuser4/user    from Team1  Admin
uiuser5/user    from Team2  Admin
superuser/user  from Team2  Superuser

For any specific questions, post it at https://kafkawize.com/community/
